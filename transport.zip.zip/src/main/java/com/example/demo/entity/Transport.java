package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transport")
public class Transport {
	@Id
	private String transportId;
	private  String customerId;
	private  String vehicleType ;
	private String  driverName;
	private  String driverPhoneNo;
	
	
	public Transport () {}
	 public Transport(String transportId, String customerId, String vehicleType, String driverName,
			String driverPhoneNo) {
		super();
		this.transportId = transportId;
		this.customerId = customerId;
		this.vehicleType = vehicleType;
		this.driverName = driverName;
		this.driverPhoneNo = driverPhoneNo;
	
	}
	public String getTransportId() {
		return transportId;
	}
	public void setTransportId(String transportId) {
		this.transportId = transportId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public String getDriverPhoneNo() {
		return driverPhoneNo;
	}
	public void setDriverPhoneNo(String driverPhoneNo) {
		this.driverPhoneNo = driverPhoneNo;
	}
	@Override
	public String toString() {
		return "Transport [transportId=" + transportId + ", customerId=" + customerId + ", vehicleType=" + vehicleType
				+ ", driverName=" + driverName + ", driverPhoneNo=" + driverPhoneNo + "]";
	}
	
	

	

}
